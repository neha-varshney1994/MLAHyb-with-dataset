#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <random>
#include <ctime>
#include <limits>
#include <map>
#include <tuple>
#include <set>
#include <queue>
#include <sstream>

using namespace std;

int global_fitness_cout;

typedef vector<vector<double>> CSRMatrix;
CSRMatrix distanceMatrix;

#define MAX_VALUE 1e9f

struct SwapperResult {
    int subFlag;
    int flag;
    double globalMin;
};

struct Item {
    vector<int> array;
    vector<int> conn;
    double cost{};
    double mst_cost{};
};

vector<Item> solutionSpace;

vector<vector<double>> readCoordinatesFromFile(const string &filename) {
    vector<vector<double>> coordinates;
    ifstream inputFile(filename);
    if (inputFile.is_open()) {
        int n;
        inputFile >> n;
        coordinates.resize(n, vector<double>(2));
        for (int i = 0; i < n; ++i) {
            inputFile >> coordinates[i][0] >> coordinates[i][1];
        }
        inputFile.close();
    } else {
        cerr << "Unable to open file: " << filename << endl;
    }
    return coordinates;
}

CSRMatrix calculateDistanceMatrix(const vector<vector<double>> &coordinates) {
    int n = coordinates.size();
    CSRMatrix distanceMatrix(n, vector<double>(n));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            distanceMatrix[i][j] = sqrt(pow(coordinates[i][0] - coordinates[j][0], 2) +
                                        pow(coordinates[i][1] - coordinates[j][1], 2));
        }
    }
    return distanceMatrix;
}

struct Compare {
    bool operator()(const pair<float, int> &a, const pair<float, int> &b) {
        return a.first > b.first;
    }
};
float primMST(const vector<vector<float>> &distance) {
    int W = distance.size();

    vector<float> key(W, numeric_limits<float>::max());
    set<int> visited;

    priority_queue<pair<float, int>, vector<pair<float, int>>, Compare> pq;

    int startNode = 0;
    key[startNode] = 0.0f;
    pq.push({0.0f, startNode});

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        if (visited.count(u) > 0)
            continue;

        visited.insert(u);

        for (int v = 0; v < W; v++) {
            if (visited.count(v) == 0 && distance[u][v] < key[v]) {
                key[v] = distance[u][v];
                pq.push({key[v], v});
            }
        }
    }

    float cost = 0;
    for (int i = 1; i < W; i++)
        cost += key[i];

    return cost;
}

float getPrimsCost(const vector<int> &nodes) {
    vector<vector<float>> subGraph(nodes.size(), vector<float>(nodes.size(), 0.0f));

    // Construct the sub-graph
    for (size_t i = 0; i < nodes.size(); i++) {
        for (size_t j = 0; j < nodes.size(); j++) {
            subGraph[i][j] = distanceMatrix[nodes[i]][nodes[j]];
        }
    }

    return primMST(subGraph);
}

//double calculateCostAndConnections(int n, vector<int> &nodes) {
//    float costInt = 0.0f;
//
//    for (int i = 0; i < n; i++) {
//        if (std::find(nodes.begin(), nodes.end(), i) != nodes.end())
//            continue;
//
//        float minDist = MAX_VALUE;
//
//        for (int j = 0; j < n / 10; j++) {
//            int intrNode = nodes[j];
//            float dist = distanceMatrix[i][intrNode];
//            if ((intrNode != i) && (dist < minDist)) {
//                minDist = dist;
//            }
//        }
//
//        costInt += minDist;
//    }
//
//    // Calculate MST cost of the given node set and add to final cost
//    costInt += getPrimsCost(nodes, distanceMatrix);
//
//    return costInt;
//}


std::tuple<double, std::vector<int>, double> calculateCostAndConnections(int n, vector<int> &nodes) {
    float costInt = 0.0f, mst_cost;
    vector<int> connections(n, -1); // initializing all nodes with -1 to start

    for (int i = 0; i < n; i++) {
        if (std::find(nodes.begin(), nodes.end(), i) != nodes.end())
            continue;

        float minDist = MAX_VALUE;
        int connectedNode = -1;

        for (int j = 0; j < n / 10; j++) {
            int intrNode = nodes[j];
            float dist = distanceMatrix[i][intrNode];
            if ((intrNode != i) && (dist < minDist)) {
                minDist = dist;
                connectedNode = intrNode;
            }
        }

        connections[i] = connectedNode;
        costInt += minDist;
    }

    // Calculate MST cost of the given node set and add to final cost

    mst_cost = getPrimsCost(nodes); // Assuming getPrimsCost function is defined elsewhere in your code
    costInt += mst_cost;

    return make_tuple(costInt, connections, mst_cost);
}

//SwapperResult swapper(int n, int idx1, int idx2, vector<vector<int>> &sublists,
//                      map<int, double> &swpCosts, const CSRMatrix &distanceMatrix,
//                      int subFlag, int flag, double globalMin_1) {
//    vector<int> &sublist1 = sublists[idx1];
//    vector<int> &sublist2 = sublists[idx2];
//
//    int nodeIdx1 = rand() % sublist1.size();
//    int nodeIdx2 = rand() % sublist2.size();
//
//    vector<int> newSet1 = sublist1;
//    vector<int> newSet2 = sublist2;
//
//    swap(newSet1[nodeIdx1], newSet2[nodeIdx2]);
//
//    double newCost1;
//    newCost1 = calculateCostAndConnections(n, newSet1);
//
//    double newCost2;
//    newCost2 = calculateCostAndConnections(n, newSet2);
//
//    int newSubFlag = subFlag;
//    int newFlag = flag;
//
//    if (newCost1 < swpCosts[idx1] || newCost2 < swpCosts[idx2]) {
//        newSubFlag = 0;
//
//        if (newCost1 < swpCosts[idx1]) {
//            sublist1 = newSet1;
//            swpCosts[idx1] = newCost1;
//        }
//
//        if (newCost2 < swpCosts[idx2]) {
//            sublist2 = newSet2;
//            swpCosts[idx2] = newCost2;
//        }
//    } else {
//        ++newSubFlag;
//    }
//
//    if (newCost1 < globalMin_1 || newCost2 < globalMin_1) {
//        newFlag = 0;
//
//        if (newCost1 < globalMin_1) {
//            globalMin_1 = newCost1;
//        }
//
//        if (newCost2 < globalMin_1) {
//            globalMin_1 = newCost2;
//        }
//    } else {
//        ++newFlag;
//    }
//
//    return {newSubFlag, newFlag, globalMin_1};
//}

//int findClosestUpperBound(const map<int, double> &cumulativeProbabilities, double num) {
//    for (const auto &entry: cumulativeProbabilities) {
//        if (entry.second >= num) {
//            return entry.first;
//        }
//    }
//    return -1;
//}

//map<int, double> generateCumulativeProbabilities(const map<int, double> &probabilities) {
//    map<int, double> cumulativeProbabilities;
//
//    double total = 0.0;
//    for (const auto& pair : probabilities) {
//        total += pair.second;
//    }
//
//    double cumulativeSum = 0.0;
//    for (const auto &entry: probabilities) {
//        cumulativeSum += entry.second;
//        cumulativeProbabilities[entry.first] = cumulativeSum / total;
//    }
//    return cumulativeProbabilities;
//}

int findClosestUpperBound(const vector<double>& cumulativeProbabilities, double num) {
    for (int i = 0; i < cumulativeProbabilities.size(); i++) {
        if (cumulativeProbabilities[i] >= num) {
            return i;  // Return the index which corresponds to the position in solutionSpace.
        }
    }
    return -1;
}

vector<double> computeProbabilities(vector<Item>& items, double totalCost) {

    if (totalCost != -1) {
        totalCost = 0.0f;
        for (const auto &item: items) {
            totalCost += item.cost;
        }
    }

    // Now, calculate the probability for each item
    double cumulativeProbability = 0.0f, probability;
    vector<double> cumulativeProbabilities;
    for (auto& item : items) {
        probability = item.cost / totalCost;
        cumulativeProbability += probability;
        cumulativeProbabilities.push_back(cumulativeProbability);
    }
    return cumulativeProbabilities;
}

vector<vector<int>> select_internal_nodes(vector<vector<int>>& internal_nodes, int n, int pop_size) {

    if (internal_nodes.size() > pop_size) {
        cerr << "Provided matrix already has more than pop_size rows." << endl;
        return internal_nodes;
    }

    //    vector<vector<int>> internal_nodes;
    vector<int> numbers(n);
    iota(numbers.begin(), numbers.end(), 0);

    for (int i = internal_nodes.size(); i < pop_size; i++) {
        random_shuffle(numbers.begin(), numbers.end());
        vector<int> nodes(numbers.begin(), numbers.begin() + n / 10);
        internal_nodes.push_back(nodes);
    }

    return internal_nodes;
}

std::tuple<double, std::vector<int>, double> smartGreedy(
        const std::vector<int>& new_set, int key, int old, int idx,
        const std::vector<Item>& df) {

    std::vector<int> conn = df[idx].conn;

    // Calculate old nodes connections to all internal nodes
    std::vector<int> cnnA;
    for (size_t i = 0; i < conn.size(); ++i) {
        if (conn[i] == old) {
            cnnA.push_back(i);
        }
    }
    cnnA.insert(cnnA.begin(), old);

    // Connect internal nodes to external nodes and calculate cost
    for (int i : cnnA) {
        double minDist = std::numeric_limits<double>::max();
        int closestNode = -1;
        for (int j : new_set) {
            if (distanceMatrix[j][i] < minDist) {
                minDist = distanceMatrix[j][i];
                closestNode = j;
            }
        }
        conn[i] = closestNode;
    }

    // Connect all external to new node
    conn[key] = -1;

    // Find potential switch indices
    std::vector<int> potential_switch_indices;
    for (size_t i = 0; i < conn.size(); ++i) {
        if (conn[i] != -1) {
            potential_switch_indices.push_back(i);
        }
    }

    // Compute the old and new costs for these nodes
    for (int idx : potential_switch_indices) {
        double cost_old = distanceMatrix[idx][conn[idx]];
        double cost_new = distanceMatrix[idx][key];

        if (cost_new < cost_old) {
            conn[idx] = key;
        }
    }

    // Calculate total cost based on connections
    double totalCost = 0.0;
    for (size_t i = 0; i < conn.size(); ++i) {
        if (conn[i] != -1) {
            totalCost += distanceMatrix[i][conn[i]];
        }
    }

    double mst_cost_new = getPrimsCost(new_set);  // MST calculation is skipped as requested

    return std::make_tuple(totalCost + mst_cost_new, conn, mst_cost_new);
}

SwapperResult swapper(int idx1, int idx2, int sub_flag, int flag, double global_min, std::vector<Item>& df) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis1(0, df[idx1].array.size() - 1);
    std::uniform_int_distribution<> dis2(0, df[idx2].array.size() - 1);

    int node_idx1 = dis1(gen);
    int node_idx2 = dis2(gen);

    std::vector<int> new_set1 = df[idx1].array;
    std::vector<int> new_set2 = df[idx2].array;

    std::swap(new_set1[node_idx1], new_set2[node_idx2]);

    // Here, we're calling smartGreedy(), which I assume you'll define elsewhere in your code.
    double new_cost1, mc1;
    std::vector<int> connections1;
    std::tie(new_cost1, connections1, mc1) = smartGreedy(new_set1, new_set1[node_idx1], new_set2[node_idx2], idx1, df);
//    std::tie(new_cost1, connections1, mc1) = calculateCostAndConnections(100, new_set1);

    double new_cost2, mc2;
    std::vector<int> connections2;
    std::tie(new_cost2, connections2, mc2) = smartGreedy(new_set2, new_set2[node_idx2], new_set1[node_idx1], idx2, df);
//    std::tie(new_cost2, connections2, mc2) = calculateCostAndConnections(100, new_set2);

    if (new_cost1 < df[idx1].cost || new_cost2 < df[idx2].cost) {
        sub_flag = 0;

        if (new_cost1 < df[idx1].cost) {
            df[idx1].array = new_set1;
            df[idx1].cost = new_cost1;
            df[idx1].conn = connections1;
            df[idx1].mst_cost = mc1;
        }

        if (new_cost2 < df[idx2].cost) {
            df[idx2].array = new_set2;
            df[idx2].cost = new_cost2;
            df[idx2].conn = connections2;
            df[idx2].mst_cost = mc2;
        }
    } else {
        sub_flag += 1;
    }

    if (new_cost1 < global_min || new_cost2 < global_min) {
        flag = 0;

        global_min = std::min({global_min, new_cost1, new_cost2});
    } else {
        flag += 1;
    }

    return {sub_flag, flag, global_min};
}

vector<vector<int>> readContent(const string &path) {
    vector<vector<int>> matrix;
    ifstream file(path);

    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            vector<int> row;
            stringstream ss(line);
            int num;
            while (ss >> num) {
                row.push_back(num);
            }
            matrix.push_back(row);
        }
        file.close();
    } else {
        cerr << "Unable to open file " << path << endl;
    }

    return matrix;
}

int main() {
    clock_t start = clock();
    srand(time(nullptr));
    cout<<'a';
//    exit(0);
    string filename = "..//dataset//lcmst1000.15.txt";
    int n, k;
    double totatCost;
    vector<vector<double>> coordinates = readCoordinatesFromFile(filename);
    distanceMatrix = calculateDistanceMatrix(coordinates);

    n = coordinates.size();
    k = static_cast<int>(0.1 * n);

    string path = "..//alcmst1000.15.txt";  // Update with your file path
    vector<vector<int>> sublists = readContent(path);


    sublists = select_internal_nodes(sublists, n, 100);

    solutionSpace.reserve(100);

    // Insert all array and its relevant cost
    for(auto& sublist : sublists) {
        Item item;
        item.array = sublist;
        std::tie(item.cost, item.conn, item.mst_cost) = calculateCostAndConnections(n, sublist);
        totatCost += item.cost; // Compute and store the cost
        solutionSpace.push_back(item);
    }

    vector<double> cumulativeProbabilities = computeProbabilities(solutionSpace, totatCost);


//    map<int, double> costs;
//    for (int i = 0; i < 100; ++i) {
//        double cost;
//        cost = calculateCostAndConnections(n, sublists[i], distanceMatrix);
//        costs[i] = cost;
//    }
//
//    map<int, double> swpCosts(costs.begin(), next(costs.begin(), 50));
//    map<int, double> cumulativeProbabilities = generateCumulativeProbabilities(swpCosts);

    int flag = 0;
    double globalMin = numeric_limits<double>::max(), globalMin_ = numeric_limits<double>::max();
//
//    clock_t start = clock();
    for (int _ = 0; _ <static_cast<int>((4 * n) + (n*n)/25) ; ++_) {
        if (flag >= 400 * n) {
            break;
        }
//
        double r1 = static_cast<double>(rand()) / RAND_MAX;
        double r2 = static_cast<double>(rand()) / RAND_MAX;

        int idx1 = findClosestUpperBound(cumulativeProbabilities, r1);
        int idx2 = findClosestUpperBound(cumulativeProbabilities, r2);

//        cout<<_;
//
        if (idx1 == idx2 || idx1 == -1 || idx2 == -1) {
            continue;
        }
//
        int subFlag = 0, as=0;
        while (as < 100) {
            as++;
//            SwapperResult swapperResult = swapper(n, idx1, idx2, sublists, swpCosts, distanceMatrix,
//                                                  subFlag, flag, globalMin);

            SwapperResult swapperResult = swapper(idx1, idx2, subFlag, flag, globalMin, solutionSpace);
            global_fitness_cout++;
            subFlag = swapperResult.subFlag;
            flag = swapperResult.flag;
            globalMin = swapperResult.globalMin;
//            cout<<" a "<<globalMin_<<' '<<globalMin;
        }
        cout << "The total fitness count: " << global_fitness_cout;
////        cout<<flag<<"a";
        if (globalMin_ > globalMin) {
            globalMin_ = globalMin;
            flag = 0;
            cout<<"\nIteration: "<<_<<" Cost: "<<globalMin_<<endl;
        }
        else {
//            cout<<flag<<endl;
            flag++;}
//        cumulativeProbabilities = computeProbabilities(solutionSpace, totatCost=-1);
    }

    auto minElement = std::min_element(solutionSpace.begin(), solutionSpace.end(),
                                       [](const Item& a, const Item& b) {
                                           return a.cost < b.cost;
                                       });

    // Display the results
    if (minElement != solutionSpace.end()) {

        std::cout << "\n Minimum Cost: " << minElement->cost << std::endl;
        std::cout << "Corresponding Array: ";
        for (int num : minElement->array) {
            std::cout << num << " ";
        }
        std::cout << std::endl;
    } else {
        std::cout << "The solution space is empty." << std::endl;
    }
//
//    int minCostIdx = min_element(swpCosts.begin(), swpCosts.end(), [](const auto &a, const auto &b) {
//        return a.second < b.second;
//    })->first;
//
//    cout << "The set of internal nodes with the minimum cost is: ";
//    for (int node: sublists[minCostIdx]) {
//        cout << node << " ";
//    }
//    cout << endl;
//
//    cout << "The minimum cost is: " << swpCosts[minCostIdx] << endl;
//
    cout << "Total execution time: " << ((double) (clock() - start)) / CLOCKS_PER_SEC << " seconds" << endl;

    return 0;
}
